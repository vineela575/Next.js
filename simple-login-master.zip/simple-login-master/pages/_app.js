import '../styles.css';
import App from 'next/app';

export default App;
